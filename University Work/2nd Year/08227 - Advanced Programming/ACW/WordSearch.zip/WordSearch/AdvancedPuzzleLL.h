#pragma once

#include "PuzzleNode.h"
#include <string>

class AdvancedPuzzleLL
{
public:
	AdvancedPuzzleLL(void);
	~AdvancedPuzzleLL(void);

	void AddPuzzleNode(const char &letter, int Xcoord, int Ycoord);

private:
	PuzzleNode *m_head;
};

