#pragma once
#include <string>


class PuzzleNode
{
public:
	PuzzleNode(char letter, int Xcoord, int Ycoord);
	~PuzzleNode(void);

	char GetLetter();
	void SetLetter(char letter);

	int GetXCoord();
	int GetYCoord();

	void SetXCoord(int Xcoord);
	void SetYCoord(int Ycoord);

private:
	char m_letter;
	int m_XCoord;
	int m_YCoord;

	PuzzleNode *m_right;
	PuzzleNode *m_left;
	PuzzleNode *m_up;
	PuzzleNode *m_down;
	PuzzleNode *m_rightUp;
	PuzzleNode *m_rightDown;
	PuzzleNode *m_leftUp;
	PuzzleNode *m_leftDown;

	friend class WordSearch;
};

