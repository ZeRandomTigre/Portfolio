#include "WordSearch.h"
#include <algorithm>
#include <iterator>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>

#include "PuzzleNode.h"

WordSearch::WordSearch() : NUMBER_OF_RUNS(500), PUZZLE_NAME("wordsearch_grid.txt"), DICTIONARY_NAME("dictionary.txt"), simplePuzzleArrayLength(0), 
												simpleDictionaryArrayLength(0), NUMBER_OF_WORDS_MATCHED(0), NUMBER_OF_GRID_CELLS_VISTED(0), 
												NUMBER_OF_DICTIONARY_ENTRIES_VISITED(0), TIME_TO_POPULATE_GIRD_STRUCTURE(0), TIME_TO_SOLVE_PUZZLE(0)
{
}

WordSearch::~WordSearch()
{
}

bool WordSearch::ReadAdvancedPuzzle()
{
	std::ifstream fileIn("wordsearch_grid.txt");

	// copy puzzle to string vector
	if (!fileIn.is_open())
	{
		return false;		
	}
	else
	{
		std::string line;

		while (std::getline(fileIn, line))
		{
			// remove white spaces from line & modify line length
			line.erase(remove(line.begin(), line.end(), ' '), line.end());

			advancedPuzzleGrid.push_back(line);
		}

		fileIn.close();
	}


	std::string vectorLine;
	PuzzleNode *node;

	for (unsigned int Y = 0; Y < advancedPuzzleGrid.size(); ++Y)
	{
		vectorLine = advancedPuzzleGrid[Y];

		for (unsigned int X = 0; X < vectorLine.length(); ++X)
		{
			node = new PuzzleNode(vectorLine[X], X, Y);
			advancedPuzzleArray[Y][X] = node;
		}
	}

	for (unsigned int Y = 0; Y < advancedPuzzleGrid.size(); ++Y)
	{
		vectorLine = advancedPuzzleGrid[Y];

		for (unsigned int X = 0; X < vectorLine.length(); ++X)
		{
			node = advancedPuzzleArray[Y][X];

			// right pointer
			if (advancedPuzzleArray[Y][X + 1] != NULL)
			{
				node->m_right = advancedPuzzleArray[Y][X + 1];
			}
			//left pointer
			if ( (advancedPuzzleArray[Y][X - 1] != NULL) && (X - 1 <= 0) )
			{
				node->m_left = advancedPuzzleArray[Y][X - 1];
			}
			// up pointer
			if ((advancedPuzzleArray[Y - 1][X] != NULL) && (Y - 1 <= 0))
			{
				node->m_up = advancedPuzzleArray[Y - 1][X];
			}
			// down pointer
			if (advancedPuzzleArray[Y + 1][X] != NULL)
			{
				node->m_down = advancedPuzzleArray[Y + 1][X];
			}
			// left up pointer
			if ((advancedPuzzleArray[Y - 1][X - 1] != NULL) && (X - 1 <= 0) && (Y - 1 <= 0))
			{
				node->m_leftUp = advancedPuzzleArray[Y - 1][X - 1];
			}
			// left down pointer
			if ((advancedPuzzleArray[Y + 1][X - 1] != NULL) && (X - 1 <= 0))
			{
				node->m_leftDown = advancedPuzzleArray[Y + 1][X - 1];
			}
			// right up pointer
			if ((advancedPuzzleArray[Y - 1][X + 1] != NULL) && (Y - 1 <= 0))
			{
				node->m_rightUp = advancedPuzzleArray[Y - 1][X + 1];
			}
			// right down pointer
			if (advancedPuzzleArray[Y + 1][X + 1] != NULL)
			{
				node->m_rightDown = advancedPuzzleArray[Y + 1][X + 1];
			}
		}
	}

	std::cout << std::endl << "ReadAdvancedPuzzle() has been read correctly" << std::endl;
	return true;
}

bool WordSearch::ReadSimplePuzzle()
{
	std::ifstream fileIn("wordsearch_grid.txt");

	// copy puzzle to 2d array
	if (fileIn.is_open())
	{
		int row = 0;
		std::string line;

		while (std::getline(fileIn, line))
		{
			// remove white spaces from line & modify line length
			line.erase(remove(line.begin(), line.end(), ' '), line.end());

			// add line chars to array
			for (unsigned int i = 0; i < line.length(); i++)
			{
				simplePuzzleArray[row][i] = line[i];
				++simplePuzzleArrayLength;				
			}
			++row;
		}

		fileIn.close();
	}

	else
	{
		std::cout << "File Does Not exist" << std::endl;
		return false;
	}

	// check if file copied correctly
	char inputCharacter;
	int row = 0;
	int column = 0;
	std::ifstream checkFileIn("wordsearch_grid.txt");
	if (checkFileIn.is_open())
	{
		while (checkFileIn.get(inputCharacter))
		{
			if (inputCharacter == '\n')
			{
				++row;
				column = 0;
			}
			else if (inputCharacter != ' ')
			{
				if (simplePuzzleArray[row][column] != inputCharacter)
				{
					std::cout << "puzzle has NOT been read correctly" << std::endl;
					return false;
				}
				++column;
			}
		}

		checkFileIn.close();
	}

	std::cout << "puzzle has been read correctly" << std::endl;
	return true;
}

bool WordSearch::ReadAdvancedDictionary()
{
	std::cout << std::endl << "ReadAdvancedDictionary() has NOT been implemented" << std::endl;
	return true;
}

bool WordSearch::ReadSimpleDictionary()
{
	// copy dictionary to array
	std::ifstream fileIn("dictionary.txt");
	if (fileIn.is_open())
	{
		std::string line;
		int count = 0;

		while (std::getline(fileIn, line))
		{
			simpleDictionaryArray[count] = line;
			++simpleDictionaryArrayLength;
			++count;
		}
	}

	// check if copied correctly
	std::ifstream checkFileIn("dictionary.txt");
	if (checkFileIn.is_open())
	{
		std::string line;
		int count = 0;
		while (std::getline(checkFileIn, line))
		{
			if (simpleDictionaryArray[count] != line)
			{
				std::cout << "simple dictionary has NOT been read correctly" << std::endl;
				return false;
			}

			++count;
		}

		std::cout << "simple dictionary has been read correctly" << std::endl;

		checkFileIn.close();

		return true;
	}

	return true;
}

bool WordSearch::SolveSimplePuzzleWithSimpleDictionary() {
	double timeTakenInSeconds;
	QueryPerformanceFrequency(&frequency);
	QueryPerformanceCounter(&start);

	for (int n = 0; n < NUMBER_OF_RUNS; ++n) {
		// Add your solving code here!

		int gridSize = sqrt(simplePuzzleArrayLength);

		NUMBER_OF_WORDS_MATCHED = 0;
		std::stringstream wordsMatchedInGrid;
		std::string *wordPtr;

		for (int row = 0; row < gridSize; ++row)
		{
			for (int column = 0; column < gridSize; ++column)
			{				
				int gridY = row;
				int gridX = column;
				
				bool wordFound = false;

				// loop through dictionary
				for (int i = 0; i < simpleDictionaryArrayLength; ++i)
				{
					wordPtr = &simpleDictionaryArray[i];

					if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[0])
					{
						// check along right direction
						for (unsigned int right = 1; right < wordPtr->length(); ++right)
						{
							++gridX;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[right])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID+NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();							
						}

						// check along left direction
						for (unsigned int left = 1; left < wordPtr->length(); ++left)
						{
							--gridX;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[left])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along down direction
						for (unsigned int down = 1; down < wordPtr->length(); ++down)
						{
							++gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[down])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along up direction
						for (unsigned int up = 1; up < wordPtr->length(); ++up)
						{
							--gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[up])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along diagonally right down
						for (unsigned int up = 1; up < wordPtr->length(); ++up)
						{
							++gridX;
							++gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[up])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along diagonally right up
						for (unsigned int up = 1; up < wordPtr->length(); ++up)
						{
							++gridX;
							--gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[up])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along diagonally left down
						for (unsigned int up = 1; up < wordPtr->length(); ++up)
						{
							--gridX;
							++gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[up])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}

						// check along diagonally left up
						for (unsigned int up = 1; up < wordPtr->length(); ++up)
						{
							--gridX;
							--gridY;
							if (simplePuzzleArray[gridY][gridX] == (*wordPtr)[up])
							{
								wordFound = true;
							}
							else
							{
								wordFound = false;
								break;
							}
						}

						gridY = row;
						gridX = column;

						if (wordFound == true)
						{
							++NUMBER_OF_WORDS_MATCHED;
							wordsMatchedInGrid.clear();
							wordsMatchedInGrid.str(std::string());
							wordsMatchedInGrid << gridX - 1 << " " << gridY - 1 << " " << (*wordPtr);
							*(WORDS_MATCH_IN_GRID + NUMBER_OF_WORDS_MATCHED) = wordsMatchedInGrid.str();
						}
					}					
				}
			}
		}				
	}

	QueryPerformanceCounter(&end);
	timeTakenInSeconds = (end.QuadPart - start.QuadPart) / (double)(frequency.QuadPart*NUMBER_OF_RUNS);


	////////////////////////////////////////////////
	// This output should be to your results file //
	////////////////////////////////////////////////
	std::cout << std::fixed << std::setprecision(10) << "SolveSimplePuzzleWithSimpleDictionary() - " << timeTakenInSeconds << " seconds" << std::endl;
	return true;
}

bool WordSearch::SolveSimplePuzzleWithAdvancedDictionary() {
	double timeTakenInSeconds;
	QueryPerformanceFrequency(&frequency);
	QueryPerformanceCounter(&start);


	for (int n = 0; n < NUMBER_OF_RUNS; ++n) 
	{
		PuzzleNode *node;
		PuzzleNode *next;
		PuzzleNode *checkWordPtr;
		std::string *testWordPtr;
		int count;
		node = advancedPuzzleArray[0][0];
		next = node->m_right;

		while (next != NULL)
		{
			for (int i = 0; i < simpleDictionaryArrayLength; ++i)
			{
				testWordPtr = &simpleDictionaryArray[i];
				checkWordPtr = node;

				if (checkWordPtr->GetLetter() == (*testWordPtr)[0])
				{
					count = 1;
					// check along right direction
					while (checkWordPtr->m_right != NULL)
					{
						checkWordPtr = checkWordPtr->m_right;
						if (checkWordPtr->GetLetter() == (*testWordPtr)[count])
							++count;
						else
							break;
					}

					count = 1;
					// check along left direction
					while (checkWordPtr->m_left != NULL)
					{
						checkWordPtr = checkWordPtr->m_left;
						if (checkWordPtr->GetLetter() == (*testWordPtr)[count])
							++count;
						else
							break;
					}

					count = 1;
					// check along up direction
					while (checkWordPtr->m_left != NULL)
					{
						checkWordPtr = checkWordPtr->m_left;
						if (checkWordPtr->GetLetter() == (*testWordPtr)[count])
							++count;
						else
							break;
					}

					count = 1;
					// check along down direction
					while (checkWordPtr->m_left != NULL)
					{
						checkWordPtr = checkWordPtr->m_left;
						if (checkWordPtr->GetLetter() == (*testWordPtr)[count])
							++count;
						else
							break;
					}

				}
			}

			next = next->m_right;
		}
	}

	QueryPerformanceCounter(&end);
	timeTakenInSeconds = (end.QuadPart - start.QuadPart) / (double)(frequency.QuadPart*NUMBER_OF_RUNS);


	////////////////////////////////////////////////
	// This output should be to your results file //
	////////////////////////////////////////////////
	std::cout << std::fixed << std::setprecision(10) << "SolveSimplePuzzleWithSimpleDictionary() - " << timeTakenInSeconds << " seconds" << std::endl;
	return true;
}

bool WordSearch::SolveAdvancedPuzzleWithSimpleDictionary() {
	std::cout << std::endl << "SolveAdvancedPuzzleWithSimpleDictionary() has NOT been implemented" << std::endl;
	return false;
}

bool WordSearch::SolveAdvancedPuzzleWithAdvancedDictionary() {
	std::cout << std::endl << "SolveAdvancedPuzzleWithAdvancedDictionary() has NOT been implemented" << std::endl;
	return false;
}

void WordSearch::WriteResults(std::string fileName)
{
	std::ofstream fileOut(fileName);

	if (fileOut.is_open())
	{
		fileOut << "NUMBER_OF_WORDS_MATCHED " << NUMBER_OF_WORDS_MATCHED << std::endl;
		fileOut << std::endl;
		fileOut << "WORDS_MATCHED_IN_GRID " << std::endl;
		for (int i = 0; i < 100; ++i)
		{
			if (!WORDS_MATCH_IN_GRID[i].empty())
			{
				fileOut << WORDS_MATCH_IN_GRID[i];
				fileOut << std::endl;
			}
		}
		fileOut << std::endl;
		fileOut << "NUMBER_OF_GRID_CELLS_VISTED " << NUMBER_OF_GRID_CELLS_VISTED << std::endl;
		fileOut << std::endl;
		fileOut << "NUMBER_OF_DICTIONARY_ENTRIES_VISITED " << NUMBER_OF_DICTIONARY_ENTRIES_VISITED << std::endl;
		fileOut << std::endl;
		fileOut << "TIME_TO_POPULATE_GRID_STRUCTURE " << TIME_TO_POPULATE_GIRD_STRUCTURE << std::endl;
		fileOut << std::endl;
		fileOut << "TIME_TO_SOLVE_PUZZLE " << TIME_TO_SOLVE_PUZZLE << std::endl;

		fileOut.close();
	}
	else
	{
		std::cout << "Write Results Error" << std::endl;
	}
}

