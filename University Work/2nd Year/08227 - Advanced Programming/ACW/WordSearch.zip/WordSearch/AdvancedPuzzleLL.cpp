#include "AdvancedPuzzleLL.h"
#include <string>


AdvancedPuzzleLL::AdvancedPuzzleLL(void) : m_head(0)
{
}


AdvancedPuzzleLL::~AdvancedPuzzleLL(void)
{
}

void AdvancedPuzzleLL::AddPuzzleNode(const char &letter, int Xcoord, int Ycoord)
{

}
