
#include <iostream>
using namespace std;

/*
* Partially completed program
* The program should copy a text file.
*
*/

bool Copy(char filenamein[], char filenameout[]);


int main(int argc, char **argv) {
	if (argc !=3) {
		cerr << "Usage: " << argv[0] << " <input filename> <output filename>" << endl;
		int keypress; cin >> keypress;
		return -1;
	}

	Copy(argv[1], argv[2]);

	system("PAUSE");
}


bool Copy(char filenamein[], char filenameout[])
{
	return false;
}
