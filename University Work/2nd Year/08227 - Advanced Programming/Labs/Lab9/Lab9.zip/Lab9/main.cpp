
#include <iostream>
using namespace std;

/*
	This program will act as a Contacts Address Book
*/

int main(int argc, char **argv) {


	system("PAUSE");
}



