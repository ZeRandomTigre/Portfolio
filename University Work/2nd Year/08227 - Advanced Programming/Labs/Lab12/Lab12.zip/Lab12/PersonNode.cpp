#include "PersonNode.h"

PersonNode::PersonNode(void)
{
}

PersonNode::~PersonNode(void)
{
}

