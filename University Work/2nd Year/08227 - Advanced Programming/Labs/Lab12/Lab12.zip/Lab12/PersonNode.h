#pragma once

#include <string>
using namespace std;

class PersonNode
{
public:
	PersonNode(void);
	~PersonNode(void);

private:
};
