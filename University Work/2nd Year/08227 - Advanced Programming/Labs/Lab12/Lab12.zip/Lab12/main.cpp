
#include <iostream>
using namespace std;
#include "AddressBookSLL.h"

/*
	This program will act as a Contacts Address Book using a Singly Linked Lists
*/

int main(int argc, char **argv) {

	AddressBookSLL book;

	system("PAUSE");
}



