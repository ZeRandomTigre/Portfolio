#include <iostream>
using namespace std;

void exercise1() {
	int a = 10;
	int b = 20;
	int *p = &a;

	cout << "a= " << a << endl;
	cout << "b= " << b << endl;

	// Add your code here

	cout << "a= " << a << endl;
	cout << "b= " << b << endl;
}

void exercise2() {
	int a = 10;
	int b = 20;
	int c = 30;
	int *p = &b;

	cout << "a= " << a << endl;
	cout << "b= " << b << endl;
	cout << "c= " << c << endl;

	*p = 100;

	cout << "a= " << a << endl;
	cout << "b= " << b << endl;
	cout << "c= " << c << endl;
}

void exercise3() {
	unsigned int a = 0x00ff00ff;
	unsigned int *p = (unsigned int *)a;

	*p = 999;
}

void exercise4() {
	double x = 3.14;

	cout << "x= " << x << endl;

	// Add code here

	cout << "x= " << x << endl;
}

void main(int, char**) {

	exercise1();
	//exercise2();
	//exercise3();
	//exercise4();

	system("PAUSE");
}
