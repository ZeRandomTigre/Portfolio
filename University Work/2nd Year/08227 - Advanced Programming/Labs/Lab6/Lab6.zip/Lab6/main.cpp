#include <iostream>
using namespace std;

void functionA(int i) {
	// range is 1, 3, 4
	if (i==1) { 
		cout << "I is 1" << endl;
	}
	if ((i>2) && (i<5)) {
		cout << "I is either 3 or 4" << endl;
	}
	if ((i!=1) && ((i<=2) || (i>=5))) {
		cout << "I is outside of range" << endl;
	}
}

bool functionB(int i) {
	if (i==1) { 
		return true;
	} else {
		return false;
	}
}

void main(int argc, char** argv) {
	int i;
	cout << "Enter an integer i " << endl;
	cin >> i;

	cout << "Calling function A - "; functionA(i);
	
	if (functionB(i))
		cout << "Function B returns true" << endl;
	else
		cout << "Function B returns false" << endl;

	system("PAUSE"); // Waits for a keypress
}